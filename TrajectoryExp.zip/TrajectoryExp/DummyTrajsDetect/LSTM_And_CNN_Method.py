"""
使用LSTM算法辨别真实轨迹和虚拟轨迹
"""
import pickle
import torch
import numpy as np
import torch.nn as nn
from torch.utils.data import Dataset

from DummyTrajsGenerate.RandomAlgorithm import GenerateRandomTrajs
from Utiliy import CoordSysConv, Model_Structures, LSTM_Extend, Utils
from DummyTrajsGenerate import MNAlgorithm, MLNAlgorithm, ADTGAAlgorithm
from Utiliy.Utils import GetDataWithBound

torch.set_printoptions(sci_mode=False)
# torch.manual_seed(3407)

# 超参数
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
dataset_size = 200
len_sections = 7  # 每个轨迹段的轨迹点数
input_size = 4  # 神经网络每个输入的大小，2表示一个经度一个纬度
hidden_size = 10  # 隐藏层单元数
num_layers = 1  # LSTM网络层数
num_classes = 2  # 类别数，只有真轨迹和假轨迹两类
batch_size = 32  # 批处理的每批数据量
num_epochs = 10  # 训练轮数
# learning_rate = 0.005  # 学习率
learning_rate = 0.0005#0.001  # 学习率
threshold = 0.5  # 判断一个轨迹真假的阈值，若真轨迹段的比例大于阈值则认为是真轨迹

# 纬度范围
minLat = 39.85
maxLat = 40.05
# 经度范围
minLng = 116.2
maxLng = 116.5
# # 纬度范围
# minLat = 39.7817
# maxLat = 40.1075
# # 经度范围
# minLng = 116.1715
# maxLng = 116.5728

LOSS = []
ACC = []

class TrajectoryDataset(Dataset):
    """
    依据Pytorch的规则制作数据集
    """
    def __init__(self, len_sections, id, gen_algorithm):
        self.len_sections = len_sections
        # 准备真实轨迹
        if gen_algorithm == "MN" or gen_algorithm == "MLN" or gen_algorithm == "Random":  # MN，MLN算法（ADTGA算法的数据预处理方法与其他方法有较大差异）
            real_data = Utils.GetDataWithBound(id, False, False, minLat, maxLat, minLng, maxLng)  # （[(lat,lng), (lat,lng),...], [(lat,lng,), (lat,lng,),...], ...）
            real_data = real_data[:dataset_size]
        elif gen_algorithm == "ADTGA":  # ADTGA算法
            pickle_file = open('ADTGA_Data_train.pkl', 'rb')
            real_data, adtga_data = pickle.load(pickle_file)
            # real_data, adtga_data = ADTGAAlgorithm.GetDataByADTGA("train", id, k_metric=0.7, tsd_metric=0.3, tdd_metric=0.003, ld_metric=0.3)
            real_data = real_data[:200]
            adtga_data = adtga_data[:200]
            # 删除重合的点，并且进行坐标转换
            real_delete_repeat = []
            dummy_delete_repeat = []
            for traj in real_data:
                tmp = []
                x_y = CoordSysConv.CoordConvert(traj[0][0], traj[0][1], minLat, minLng)
                tmp.append(x_y)
                for i in range(1, len(traj)):
                    if not (traj[i][0] == traj[i - 1][0] and traj[i][1] == traj[i - 1][1]):
                        x_y = CoordSysConv.CoordConvert(traj[i][0], traj[i][1], minLat, minLng)
                        tmp.append(x_y)
                if len(tmp) > 3:
                    real_delete_repeat.append(tmp)
            real_data = real_delete_repeat
            for traj in adtga_data:
                tmp = []
                x_y = CoordSysConv.CoordConvert(traj[0][0], traj[0][1], minLat, minLng)
                tmp.append(x_y)
                for i in range(1, len(traj)):
                    if not (traj[i][0] == traj[i - 1][0] and traj[i][1] == traj[i - 1][1]):
                        x_y = CoordSysConv.CoordConvert(traj[i][0], traj[i][1], minLat, minLng)
                        tmp.append(x_y)
                if len(tmp) > 3:
                    dummy_delete_repeat.append(tmp)
        elif gen_algorithm == "Anotherme":
            pickle_file = open('/Users/zhangwenbo/Documents/研究生资料/代码/TrajectoryExp/DummyTrajsDetect/Anotherme_train.pkl', 'rb')
            real_data, dummy_delete_repeat = pickle.load(pickle_file)
            real_data = [[point[:2] for point in traj] for traj in real_data]
            dummy_delete_repeat = [[point[:2] for point in traj] for traj in dummy_delete_repeat]


        # 真实数据分段
        real_sections = []  # [ ([X,Y,roa,rl], [X,Y,roa,rl], ...), ([X,Y,roa,rl], [X,Y,roa,rl], ...), ...]
        for traj in real_data:
            traj = traj[:(len(traj) // self.len_sections) * self.len_sections]  # 切除分段多余部分
            traj = np.array(traj).reshape(len(traj) // self.len_sections, self.len_sections, 2)  # 分段
            for sec in traj:
                real_sections.append(self.CalAttrs(sec))
        real_sections = real_sections[:1012]
        print("真实轨迹段数: ", len(real_sections))
        # 准备虚拟轨迹
        dummy_data = []
        num_dummy_traj = int(len(real_sections) * len_sections / 800)
        print("虚假轨迹数(MN/MLN): ", num_dummy_traj)

        if gen_algorithm == "MLN":  # MLN需要用到原始数据
            otherLocations = MLNAlgorithm.GetOtherLocations(id, with_t=False, convert=False, max_lng=maxLng, min_lng=minLng,
                                                            max_lat=maxLat, min_lat=minLat)
        if gen_algorithm == "MN" or gen_algorithm == "MLN":
            for i in range(num_dummy_traj):
                dummy_traj_converted = []
                dummy_traj = []
                if gen_algorithm == "MN":
                    dummy_traj = MNAlgorithm.MovingInNeighborhood(m=0.0001, n=800, with_t=False,
                                                 max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)  # 生成单条轨迹
                elif gen_algorithm == "MLN":
                    # print("{}/{}".format(i, num_dummy_traj))
                    dummy_traj = MLNAlgorithm.MovingInNeighborhood(aveP=100, m=0.0001, n=800, otherLocations=otherLocations, with_t=False,
                                                 max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)  # 生成单条轨迹

                # elif gen_algorithm = GenerateRandomTrajs()
                # for point in dummy_traj:
                #     dummy_traj_converted.append(CoordSysConv.CoordConvert(point[0], point[1], minLat, minLng))
                # dummy_data.append(dummy_traj_converted)
                dummy_data.append(dummy_traj)
        elif gen_algorithm == "Random":
            dummy_data = GenerateRandomTrajs(num_dummy_traj, 800, with_t=False, max_lng=maxLng, min_lng=minLng, max_lat=maxLat,
                                         min_lat=minLat)

        else:
            dummy_data = dummy_delete_repeat

        # 虚拟数据分段
        dummy_sections = []
        for traj in dummy_data:
            traj = traj[:(len(traj) // self.len_sections) * self.len_sections]  # 切除分段多余部分
            traj = np.array(traj).reshape(len(traj) // self.len_sections, self.len_sections, 2)  # 分段
            for sec in traj:
                dummy_sections.append(self.CalAttrs(sec))
        print("虚拟轨迹段数: ", len(dummy_sections))


        # real_sections = real_sections[:10000]
        # dummy_sections = dummy_sections[:10000]
        data = real_sections + dummy_sections
        self.tensor_data = torch.tensor(data).float()
        self.num_real_secs = len(real_sections)

    def CalAttrs(self, sec):
        """
        对于一段轨迹，计算其信息([X, Y, roa, rl])
        :param sec: [(lat,lng), (lat,lng), ...]
        :return: ([X, Y, roa, rl], [X, Y, roa, rl], ...)
        """
        total_l = 0
        result = [[0, 0, 0, 0] for i in range(len(sec))]
        for i in range(1, len(sec)):  # 计算总距离
            total_l += Utils.CalDist(sec[i], sec[i - 1])
        for i in range(len(sec)):  # 计算rl
            if i != 0:
                dis = Utils.CalDist(sec[i], sec[i - 1])
            else:
                dis = 0
            rn = dis / (total_l + 1e-10)
            result[i][3] = rn
        for i in range(len(sec)):  # 计算roa
            if i == 0 or i == 1:
                roa = 0.
                result[i][2] = roa
            else:
                roa = LSTM_Extend.CalRoa(sec[i - 2][0], sec[i - 2][1], sec[i - 1][0], sec[i - 1][1], sec[i][0], sec[i][1])
                result[i][2] = roa

        X_list = []
        Y_list = []
        for i in range(len(sec)):
            if i == 0:
                X_list.append(0)
                Y_list.append(0)
            else:
                X = sec[i][1] - sec[i - 1][1]
                Y = sec[i][0] - sec[i - 1][0]
                X_list.append(X)
                Y_list.append(Y)
        Y_min = min(Y_list)
        Y_max = max(Y_list)
        X_min = min(X_list)
        X_max = max(X_list)

        for i in range(1, len(sec)):
            result[i][0] = (X_list[i] - X_min) / (X_max - X_min + 1e-10)
            result[i][1] = (Y_list[i] - Y_min) / (Y_max - Y_min + 1e-10)

        return result

    def __getitem__(self, index):
        """
        必须实现，作用是:获取索引对应位置的一条数据
        :param index: 索引号
        :return: data, label
        """
        self.true_index = self.num_real_secs
        if index < self.true_index:
            label = 1
        else:
            label = 0
        return self.tensor_data[index], label

    def __len__(self):
        """
        必须实现，作用是得到数据集的大小
        :return: 数据集大小
        """
        return self.tensor_data.shape[0]


class TestDataset(Dataset):
    """
    依据Pytorch的规则制作数据集
    """
    def __init__(self, len_sections, id, gen_algorithm):
        self.len_sections = len_sections
        # 准备真实轨迹
        real_data = []
        if gen_algorithm == "MN" or gen_algorithm == "MLN" or gen_algorithm == "Random":  # MN，MLN算法（ADTGA算法的数据预处理方法与其他方法有较大差异）
            real_data = Utils.GetDataWithBound(id, False, False, minLat, maxLat, minLng, maxLng)  # （[(lat,lng), (lat,lng),...], [(lat,lng,), (lat,lng,),...], ...）
            real_data = real_data[dataset_size : dataset_size + int(0.2 * dataset_size)]
        else:  # ADTGA算法
            pickle_file = open('ADTGA_Data_test.pkl', 'rb')
            real_data, adtga_data = pickle.load(pickle_file)
            # real_data, adtga_data = ADTGAAlgorithm.GetDataByADTGA("test", id, k_metric=0.7, tsd_metric=0.3, tdd_metric=0.003, ld_metric=0.3)
            # real_data = real_data[:40]
            # adtga_data = adtga_data[:40]
            # 删除重合的点，并且进行坐标转换
            real_delete_repeat = []
            dummy_delete_repeat = []
            for traj in real_data:
                tmp = []
                x_y = CoordSysConv.CoordConvert(traj[0][0], traj[0][1], minLat, minLng)
                tmp.append(x_y)
                for i in range(1, len(traj)):
                    if not (traj[i][0] == traj[i - 1][0] and traj[i][1] == traj[i - 1][1]):
                        x_y = CoordSysConv.CoordConvert(traj[i][0], traj[i][1], minLat, minLng)
                        tmp.append(x_y)
                if len(tmp) > 3:
                    real_delete_repeat.append(tmp)
            real_data = real_delete_repeat
            for traj in adtga_data:
                tmp = []
                x_y = CoordSysConv.CoordConvert(traj[0][0], traj[0][1], minLat, minLng)
                tmp.append(x_y)
                for i in range(1, len(traj)):
                    if not (traj[i][0] == traj[i - 1][0] and traj[i][1] == traj[i - 1][1]):
                        x_y = CoordSysConv.CoordConvert(traj[i][0], traj[i][1], minLat, minLng)
                        tmp.append(x_y)
                if len(tmp) > 3:
                    dummy_delete_repeat.append(tmp)
            # dummy_trajs = dummy_delete_repeat

        # 真实数据分段
        real_trajs = []
        for traj in real_data:
            real_sections = []  # [ ([X,Y,roa,rl], [X,Y,roa,rl], ...), ([X,Y,roa,rl], [X,Y,roa,rl], ...), ...]
            traj = traj[:(len(traj) // self.len_sections) * self.len_sections]  # 切除分段多余部分
            traj = np.array(traj).reshape(len(traj) // self.len_sections, self.len_sections, 2)  # 分段
            for sec in traj:
                real_sections.append(self.CalAttrs(sec))
            real_trajs.append(real_sections)
        # 准备虚拟轨迹
        dummy_data = []
        num_dummy_traj = len(real_data)

        if gen_algorithm == "MLN":  # MLN需要用到原始数据
            otherLocations = MLNAlgorithm.GetOtherLocations(id, with_t=False, convert=False, max_lng=maxLng, min_lng=minLng,
                                                            max_lat=maxLat, min_lat=minLat)
        if gen_algorithm == "MN" or gen_algorithm == "MLN":
            for i in range(num_dummy_traj):
                dummy_traj_converted = []
                dummy_traj = []
                if gen_algorithm == "MN":
                    dummy_traj = MNAlgorithm.MovingInNeighborhood(m=0.0001, n=800, with_t=False,
                                                 max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)  # 生成单条轨迹
                elif gen_algorithm == "MLN":
                    dummy_traj = MLNAlgorithm.MovingInNeighborhood(aveP=50, m=0.0001, n=800, otherLocations=otherLocations, with_t=False,
                                                 max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)  # 生成单条轨迹
                # for point in dummy_traj:
                #     dummy_traj_converted.append(CoordSysConv.CoordConvert(point[0], point[1], minLat, minLng))
                # dummy_data.append(dummy_traj_converted)
                dummy_data.append(dummy_traj)
        elif gen_algorithm == "Random":
            dummy_data = GenerateRandomTrajs(num_dummy_traj, 800, with_t=False, max_lng=maxLng, min_lng=minLng,
                                             max_lat=maxLat, min_lat=minLat)
        else:
            dummy_data = dummy_delete_repeat

        dummy_trajs = []
        for traj in dummy_data:
            dummy_sections = []
            traj = traj[:(len(traj) // self.len_sections) * self.len_sections]  # 切除分段多余部分
            traj = np.array(traj).reshape(len(traj) // self.len_sections, self.len_sections, 2)  # 分段
            for sec in traj:
                dummy_sections.append(self.CalAttrs(sec))
            dummy_trajs.append(dummy_sections)

        self.data = real_trajs + dummy_trajs

    def CalAttrs(self, sec):
        """
        对于一段轨迹，计算其信息([X, Y, roa, rl])
        :param sec: [(lat,lng), (lat,lng), ...]
        :return: ([X, Y, roa, rl], [X, Y, roa, rl], ...)
        """
        total_l = 0
        result = [[0, 0, 0, 0] for i in range(len(sec))]
        for i in range(1, len(sec)):  # 计算总距离
            total_l += Utils.CalDist(sec[i], sec[i - 1])
        for i in range(len(sec)):  # 计算rl
            if i != 0:
                dis = Utils.CalDist(sec[i], sec[i - 1])
            else:
                dis = 0
            rn = dis / (total_l + 1e-10)
            result[i][3] = rn
        for i in range(len(sec)):  # 计算roa
            if i == 0 or i == 1:
                roa = 0.
                result[i][2] = roa
            else:
                roa = LSTM_Extend.CalRoa(sec[i - 2][0], sec[i - 2][1], sec[i - 1][0], sec[i - 1][1], sec[i][0],
                                         sec[i][1])
                result[i][2] = roa

        X_list = []
        Y_list = []
        for i in range(len(sec)):
            if i == 0:
                X_list.append(0)
                Y_list.append(0)
            else:
                X = sec[i][1] - sec[i - 1][1]
                Y = sec[i][0] - sec[i - 1][0]
                X_list.append(X)
                Y_list.append(Y)
        Y_min = min(Y_list)
        Y_max = max(Y_list)
        X_min = min(X_list)
        X_max = max(X_list)

        for i in range(1, len(sec)):
            result[i][0] = (X_list[i] - X_min) / (X_max - X_min + 1e-10)
            result[i][1] = (Y_list[i] - Y_min) / (Y_max - Y_min + 1e-10)

        return result

    def __getitem__(self, index):
        """
        必须实现，作用是:获取索引对应位置的一条数据
        :param index: 索引号
        :return: data, label
        """
        self.true_index = int(0.5 * len(self.data))
        if index < self.true_index:
            label = 1
        else:
            label = 0
        return self.data[index], label

    def __len__(self):
        """
        必须实现，作用是得到数据集的大小
        :return: 数据集大小
        """
        return len(self.data)


def TrainAndEvaluate(model_name):
    """
    模型训练
    :model_name: 模型名称，可选LSTM和CNN
    :param train_loader: 符合pytorch规则的训练集DataLoader
    :return: 训练好的模型
    """
    return_model = None
    if model_name == "LSTM":
        model = Model_Structures.LSTM(input_size, hidden_size, num_layers, num_classes, device).to(device)
    elif model_name == "CNN":
        model = Model_Structures.CNN(len_sections, hidden_size, num_classes, alpha=0.5).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    print("开始训练，模型为", model_name)

    total_step = len(train_loader)

    max_acc = 0
    for epoch in range(num_epochs):
        for i, (sections, labels) in enumerate(train_loader):
            sections = sections.reshape(-1, len_sections, input_size).to(device)
            labels = labels.to(device)

            if model_name == "LSTM":
                outputs = model(sections)
            elif model_name == "CNN":
                ft = sections[:, :, 2:]
                ft = torch.permute(ft, (0, 2, 1))
                rt = sections[:, :, :2]
                rt = torch.permute(rt, (0, 2, 1))
                outputs = model(ft, rt)

            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            # print(i+1)
            if (i + 1) % 30 == 0:
                print('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'
                      .format(epoch + 1, num_epochs, i + 1, total_step, loss.item()))
        LOSS.append(loss.item())
        acc = Evaluate(model_name, model)
        ACC.append(acc)
        if acc > max_acc:
            max_acc = acc
            # 保存
            torch.save(model, model_name + "_Model.pkl")
            return_model = model
            print("保存模型到" + model_name + "_Model.pkl")
    print("\nBest Acc: ", max_acc)
    return return_model


def Evaluate(model_name, model):
    """
    模型测试
    :param model: 训练好的模型
    :param test_loader: 符合pytorch规则的训练集DataLoader
    :return: 把模型保存到本地文件model.ckpt
    """
    # 开始测试
    model.eval()
    with torch.no_grad():
        correct = 0
        total = 0
        for sections, labels in val_loader:
            sections = sections.reshape(-1, len_sections, input_size).to(device)
            labels = labels.to(device)
            if model_name == "LSTM":
                outputs = model(sections)
            elif model_name == "CNN":
                ft = sections[:, :, 2:]
                ft = torch.permute(ft, (0, 2, 1))
                rt = sections[:, :, :2]
                rt = torch.permute(rt, (0, 2, 1))
                outputs = model(ft, rt)
            _, predicted = torch.max(outputs.data, 1)
            print(predicted)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        print('Test Accuracy of the model on the test sections: {} %'.format(100 * correct / total))
    return correct / total


def Recognition(model, traj):
    """
    检测一个轨迹是真轨迹还是虚拟轨迹
    :param model: 训练好的模型
    :param traj: 列表格式的轨迹，维度为[x, 2], x为轨迹长度
    :return:
    points = points[:(len(points) // self.len_sections) * self.len_sections]  # 切除分段多余部分
        self.real_data = np.array(points).reshape(len(points) // self.len_sections, self.len_sections, 2)  # 分段
    """
    traj = traj[:(len(traj) // len_sections) * len_sections]  # 切除分段多余部分
    traj = np.array(traj).reshape(len(traj) // len_sections, len_sections, 2)  # 分段
    traj = torch.from_numpy(traj).float()
    num_real = 0  # 真轨迹段个数
    num_total = traj.shape[0]  # 总轨迹段个数
    print("num_total", num_total)
    with torch.no_grad():
        for i in range(num_total):
            section = traj[i]  # 截取出轨迹段
            result = model(section.unsqueeze(0))  # 对轨迹段使用LSTM鉴别
            _, predicted = torch.max(result.data, 1)
            if predicted == 1:
                num_real += 1
    if num_total == 0:
        return False
    if num_real / num_total > threshold:
        return True
    return False


def Test(model_name, test_set):
    # 读取
    model = torch.load(model_name + "_Model.pkl")
    print("开始测试，读取模型")

    test_loader = torch.utils.data.DataLoader(test_set, batch_size=1, shuffle=False, num_workers=0)
    accurate = 0
    all = len(test_loader)
    for batch_idx, (data, target) in enumerate(test_loader):  # data是轨迹段组成的列表
        print("batch_idx: ", batch_idx)
        num_secs = len(data)
        if num_secs == 0:
            continue
        num_true_detect = 0
        for sec in data:
            with torch.no_grad():
                sec = torch.Tensor(sec).to(torch.float32)
                sections = sec.unsqueeze(0)
                if model_name == "LSTM":
                    outputs = model(sections)
                elif model_name == "CNN":
                    ft = sections[:, :, 2:]
                    ft = torch.permute(ft, (0, 2, 1))
                    rt = sections[:, :, :2]
                    rt = torch.permute(rt, (0, 2, 1))
                    outputs = model(ft, rt)
                result = outputs  # 对轨迹段使用LSTM鉴别
                _, predicted = torch.max(result.data, 1)
                if predicted == 1:  # 对轨迹段预测为真
                    num_true_detect += 1
        print("num_true_detect:", num_true_detect)
        print("num_secs:", num_secs)
        if num_true_detect / num_secs >= threshold:  # 对整个轨迹预测为真
            if target == 1:
                print("预测正确")
                accurate += 1
            else:
                print("预测错误")
        else:  # 对整个轨迹预测为假
            if target == 0:
                print("预测正确")
                accurate += 1
            else:
                print("预测错误")
    print(accurate)
    print("测试准确率为{}%".format(accurate / all * 100.))


if __name__ == '__main__':
    # 数据集准备
    model_name = "CNN"
    gen_algorithm = "Anotherme"
    id = "-1"

    dataset = TrajectoryDataset(len_sections, id, gen_algorithm)
    train_size, val_size = int(0.8 * len(dataset)), len(dataset)-int(0.8 * len(dataset))
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=1)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=1)
    # 开始训练及评估
    model = TrainAndEvaluate(model_name)

    test_set = TestDataset(len_sections=len_sections, id=id, gen_algorithm=gen_algorithm)
    Test(model_name, test_set)
    print("Loss: ", LOSS)
    print("Acc:", ACC)
