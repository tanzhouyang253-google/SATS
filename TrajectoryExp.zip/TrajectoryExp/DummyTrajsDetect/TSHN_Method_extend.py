"""
使用TSHN算法辨别真实轨迹和虚拟轨迹
"""
import pickle
import random

import torch
import torch.nn as nn
from torch import optim
from torch.utils.data import Dataset

from DummyTrajsGenerate import ADTGAAlgorithm
from Utiliy.ADTGA_Utils import GenerateDummyTrajectory, EncodeTrajWithIT2I, EncodeInd
from Utiliy import Model_Structures
from Utiliy.Utils import GetDataWithBound, CalRegion
torch.manual_seed(3407)

num_epochs = 10
batch_size = 64#64 200
learning_rate = 0.001
dataset_size = 201#80  # 201条真实数据生成200组真真数据，同样再生成200组真假数据
train_set_size = 2 * int(0.8 * (dataset_size - 1))  # 真真数据40组，真假数据40组
# training_set_size = 79 * 2
val_set_size = 2 * int(0.2 * (dataset_size - 1))  # 真真数据40组，真假数据40组
test_set_size = 2 * int(0.2 * (dataset_size - 1))  # 真实数据40条，虚假数据40条

# testing_set_size = 19 * 2  # 19
id = "003"
LOSS = []
ACC = []
# region = CalRegion(id, min_lat=-90, max_lat=90, min_lng=-180, max_lng=180)
# print(region)
# # 纬度范围
# minLat = 39.7817
# maxLat = 40.1075
# # 经度范围
# minLng = 116.1715
# maxLng = 116.5728
# 纬度范围
minLat = 39.85
maxLat = 40.05
# 经度范围
minLng = 116.2
maxLng = 116.5


class TrajectoryDataset(Dataset):
    """
    依据Pytorch的规则制作数据集
    """
    def __init__(self, gen_algorithm):
        """
        数据初始化
        :param train_mode: 训练模式和测试模式返回不同的数据集
        """
        if gen_algorithm == "MN" or gen_algorithm == "MLN" or gen_algorithm == "Random":
            # 准备真实轨迹数据并编码
            data = GetDataWithBound(id, True, False, minLat, maxLat, minLng, maxLng)
            data = data[:dataset_size]
            real_traj_feature_list = []
            for i in range(len(data)):
                M = EncodeTrajWithIT2I(data[i])
                Ind = EncodeInd(data[i])
                real_traj_feature_list.append([M, Ind])
            # 准备虚拟轨迹数据并编码
            dummy_traj_feature_list = GenerateDummyTrajectory(dataset_size, id, mode=gen_algorithm)  # 格式与真实数据相同

        elif gen_algorithm == "ADTGA":
            # real_data, adtga_data = ADTGAAlgorithm.GetDataByADTGA("train", id, k_metric=0.5, tsd_metric=0.3, tdd_metric=0.001, ld_metric=0.3)  # 格式与真实数据相同
            pickle_file = open('./ADTGA_Data_train.pkl', 'rb')
            real_data, adtga_data = pickle.load(pickle_file)
            real_data = real_data[:201]
            adtga_data = adtga_data[:201]
            real_traj_feature_list = []
            for i in range(len(real_data)):
                M = EncodeTrajWithIT2I(real_data[i])
                Ind = EncodeInd(real_data[i])
                real_traj_feature_list.append([M, Ind])
            dummy_traj_feature_list = []
            for i in range(len(adtga_data)):
                M = EncodeTrajWithIT2I(adtga_data[i])
                Ind = EncodeInd(adtga_data[i])
                dummy_traj_feature_list.append([M, Ind])
        elif gen_algorithm == "Anotherme":
            pickle_file = open('./Anotherme_train.pkl', 'rb')
            real_data, anotherme_data = pickle.load(pickle_file)
            # real_data = real_data[:80]
            # anotherme_data = anotherme_data[:80]
            real_traj_feature_list = []
            for i in range(len(real_data)):
                M = EncodeTrajWithIT2I(real_data[i])
                Ind = EncodeInd(real_data[i])
                real_traj_feature_list.append([M, Ind])
            dummy_traj_feature_list = []
            for i in range(len(anotherme_data)):
                M = EncodeTrajWithIT2I(anotherme_data[i])
                Ind = EncodeInd(anotherme_data[i])
                dummy_traj_feature_list.append([M, Ind])

        print("训练和评估数据读取和生成完毕")
        # 格式转换，划分训练集和测试集
        similar = []
        non_similar = []
        # for i in range(dataset_size - 1):  # 相似数据集
        #     similar.append([real_traj_feature_list[i][0] - real_traj_feature_list[i + 1][0],
        #                          real_traj_feature_list[i][1] - real_traj_feature_list[i + 1][1]])
        # for i in range(dataset_size - 1):  # 不相似数据集
        #     non_similar.append([real_traj_feature_list[i][0] - dummy_traj_feature_list[i + 1][0],
        #                          real_traj_feature_list[i][1] - dummy_traj_feature_list[i + 1][1]])


        for i in range(dataset_size - 1):  # 相似数据集
            for j in range(i + 1, dataset_size - 1):
                print(i, j)
                similar.append([real_traj_feature_list[i][0], real_traj_feature_list[i][1],
                                real_traj_feature_list[j][0], real_traj_feature_list[j][1]])
        for i in range(dataset_size - 1):  # 不相似数据集
            for j in range(i + 1, dataset_size - 1):
                non_similar.append([real_traj_feature_list[i][0], real_traj_feature_list[i][1],
                                    dummy_traj_feature_list[j][0], dummy_traj_feature_list[j][1]])
                print(i, j)

        self.data = similar + non_similar
        self.num_similar = len(similar)
        print("self.num_similar", self.num_similar)

    def __getitem__(self, index):
        """
        必须实现，获取索引对应位置的一条数据
        :param index: 索引号
        :return: data, label
        """
        self.similar_index = self.num_similar
        if index < self.similar_index:
            label = 100.
        else:
            label = 0.
        return self.data[index], label

    def __len__(self):
        """
        必须实现，得到数据集的大小
        :return: 数据集大小
        """
        return len(self.data)


class TestDataset(Dataset):
    """
    依据Pytorch的规则制作数据集
    """
    def __init__(self, gen_algorithm):
        """
        数据初始化
        :param train_mode: 训练模式和测试模式返回不同的数据集
        """
        if gen_algorithm == "MN" or gen_algorithm == "MLN" or gen_algorithm == "Random":
            # 准备真实轨迹数据并编码
            data = GetDataWithBound(id, True, False, minLat, maxLat, minLng, maxLng)
            data = data[dataset_size : int(dataset_size + test_set_size / 2)]
            real_traj_feature_list = []
            for i in range(len(data)):
                M = EncodeTrajWithIT2I(data[i])
                Ind = EncodeInd(data[i])
                real_traj_feature_list.append([M, Ind])
            # 准备虚拟轨迹数据并编码
            dummy_traj_feature_list = GenerateDummyTrajectory(int(test_set_size / 2), id, mode=gen_algorithm)  # 格式与真实数据相同

        elif gen_algorithm == "ADTGA":
            # real_data, adtga_data = ADTGAAlgorithm.GetDataByADTGA("test", id, k_metric=0.5, tsd_metric=0.3, tdd_metric=0.001, ld_metric=0.3)  # 格式与真实数据相同
            pickle_file = open('./ADTGA_Data_test.pkl', 'rb')
            real_data, adtga_data = pickle.load(pickle_file)
            real_data = real_data[:40]
            adtga_data = adtga_data[:40]
            real_traj_feature_list = []
            for i in range(len(real_data)):
                M = EncodeTrajWithIT2I(real_data[i])
                Ind = EncodeInd(real_data[i])
                real_traj_feature_list.append([M, Ind])
            dummy_traj_feature_list = []
            for i in range(len(adtga_data)):
                M = EncodeTrajWithIT2I(adtga_data[i])
                Ind = EncodeInd(adtga_data[i])
                dummy_traj_feature_list.append([M, Ind])
        elif gen_algorithm == "Anotherme":
            pickle_file = open('./Anotherme_test.pkl', 'rb')
            real_data, anotherme_data = pickle.load(pickle_file)
            real_data = real_data[:20]
            anotherme_data = anotherme_data[:20]
            real_traj_feature_list = []
            for i in range(len(real_data)):
                M = EncodeTrajWithIT2I(real_data[i])
                Ind = EncodeInd(real_data[i])
                real_traj_feature_list.append([M, Ind])
            dummy_traj_feature_list = []
            for i in range(len(anotherme_data)):
                M = EncodeTrajWithIT2I(anotherme_data[i])
                Ind = EncodeInd(anotherme_data[i])
                dummy_traj_feature_list.append([M, Ind])


        print("测试数据读取和生成完毕")
        self.data = real_traj_feature_list + dummy_traj_feature_list

    def __getitem__(self, index):
        """
        必须实现，获取索引对应位置的一条数据
        :param index: 索引号
        :return: data, label
        """
        self.real_index = int(len(self.data) / 2)
        if index < self.real_index:
            label = 1
        else:
            label = 0
        return self.data[index], label

    def __len__(self):
        """
        必须实现，得到数据集的大小
        :return: 数据集大小
        """
        return len(self.data)



def CalAccuracy(pred, label):
    """
    计算模型准确率
    :param pred: 模型预测值
    :param label: 对应标签值
    :return:
    """
    tp, tn, fn, fp = 0, 0, 0, 0
    val = abs(pred.item() - label.item())
    pred = pred.item()
    if pred >= 50 and label >= 50:  # 预测对的正例
        tp = tp + 1
    if pred < 50 and label < 50:   # 预测对的负例
        tn = tn + 1
    if pred >= 50 and label < 50:    # 预测错的负例
        fn = fn + 1
    if pred < 50 and label >= 50:   # 预测错的正例
        fp = fp + 1

    return tp, tn, fn, fp


def TrainAndEvaluate(train_loader, val_loader):
    """
    模型训练评估
    :param train_loader: Pytorch Dataloader格式的训练集
    :param val_loader: Pytorch Dataloader格式的测试集
    """
    model = Model_Structures.TSHN_Extend()
    criterion = nn.MSELoss()
    # criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-3)

    max_acc = 0
    for epoch in range(num_epochs):
        tmp_loss = 0
        for batch_idx, (data, target) in enumerate(train_loader):
            model.train()
            output = model(data[0], data[1], data[2], data[3])
            # print(output)
            target = target.to(torch.float32)
            loss = criterion(output, target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            tmp_loss = loss.data.numpy()
        LOSS.append(loss.item())
        print("epoch:", epoch)
        print("loss:", tmp_loss)

        TP = 0  # 被模型预测为正类的正样本
        TN = 0  # 被模型预测为负类的负样本
        FN = 0  # 被模型预测为正类的负样本
        FP = 0  # 被模型预测为负类的正样本
        model.eval()
        with torch.no_grad():
            for (data_test, target_test) in val_loader:
                output_test = model(data_test[0], data_test[1], data_test[2], data_test[3])
                target_test = target_test.to(torch.float32)
                # print("out ", output_test, "tar ", target_test)
                tp, tn, fn, fp = CalAccuracy(output_test, target_test)
                TP = TP + tp
                TN = TN + tn
                FN = FN + fn
                FP = FP + fp
        acc = (TP + TN) / (TP + TN + FN + FP)
        ACC.append(acc)
        if acc > max_acc:
            max_acc = acc
            # 保存
            torch.save(model, "TSHN_Model.pkl")
            print("保存模型到 TSHN_Model.pkl")
        print("acc:", acc, "TP:", TP, "TN:", TN, "FN:", FN, "FP:", FP)
    print("\nBest Acc: ", max_acc)


def Test(test_set):
    # 读取
    model = torch.load("TSHN_Model.pkl")
    print("开始测试，读取模型")
    # 取100条真实数据，测试时把需要检测的轨迹分别与100条真实轨迹对比
    data = GetDataWithBound(id, True, False, minLat, maxLat, minLng, maxLng)
    data = data[:100]
    real_traj_feature_list = []

    traj_len = 100
    datapart=[]
    for i in range(len(data)):
        num_points = len(data[i])
        if num_points > traj_len:
            start = random.randint(0, num_points - traj_len)
            traj = data[i][start:start + traj_len]
        else:
            traj = data[i]
        datapart.append(traj)
    for i in range(len(datapart)):
        M = EncodeTrajWithIT2I(datapart[i])
        Ind = EncodeInd(datapart[i])
        real_traj_feature_list.append([M, Ind])

    test_loader = torch.utils.data.DataLoader(test_set, batch_size=1, shuffle=False, num_workers=0)
    all = len(test_loader)
    accurate = 0

    for batch_idx, (data, target) in enumerate(test_loader):
        with torch.no_grad():
            print("batch_idx: ", batch_idx)
            num_similar = 0
            for i in range(100):
                delta_M = torch.abs(real_traj_feature_list[i][0] - data[0])
                delta_Ind = torch.abs(real_traj_feature_list[i][1] - data[1])
                pred = model(delta_M, delta_Ind)
                # print("pred", pred, "target", target)
                if pred > 50:  # 相似度大于50分则认为两轨迹相似
                    num_similar += 1
            print("num_similar ", num_similar)
            # 与50条以上真实轨迹相似，认为是真实轨迹，若标签为1，则说明预测正确
            # 与50条以下真实轨迹相似，认为是虚假轨迹，若标签为0，则说明预测正确
            if (num_similar >= 50 and target == 1) or (num_similar < 50 and target == 0):
                print("预测正确")
                accurate += 1
            else:
                print("预测错误")
    print(accurate)
    print("测试准确率为{}%".format(accurate / all * 100.))


if __name__ == '__main__':
    gen_algorithm = "MLN"
    dataset = TrajectoryDataset(gen_algorithm=gen_algorithm)
    train_set_size = int(0.8 * len(dataset))
    val_set_size = len(dataset) - train_set_size
    train_set, val_set = torch.utils.data.random_split(dataset, [train_set_size, val_set_size])
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = torch.utils.data.DataLoader(val_set, batch_size=1, shuffle=True, num_workers=0)
    model = TrainAndEvaluate(train_loader, val_loader)

    test_set = TestDataset(gen_algorithm=gen_algorithm)
    # Test(test_set)
    print("Loss: ", LOSS)
    print("Acc:", ACC)





