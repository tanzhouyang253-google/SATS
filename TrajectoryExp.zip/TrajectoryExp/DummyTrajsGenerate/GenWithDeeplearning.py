import random
import numpy as np
from Utiliy.LSTM_Extend import *


class Map:
    """
    可以将轨迹数据映射在真实地区地图上，并标记热点区域、禁止区域，并依据此生成虚拟轨迹
    """
    def __init__(self, x_min, x_max, y_min, y_max, grid_num):
        # 位置坐标用实际数值表示，网格坐标从(0,0)开始
        # 地图边界
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max

        self.map_size = x_max - x_min  # 地图长/宽
        self.grid_num = grid_num  # 每行/列网格数
        self.grid_size = self.map_size / grid_num  # 单个网格大小
        self.map = [[0 for j in range(grid_num)] for i in range(self.grid_num)]  # 二维列表表示地图
        self.hot_list = []  # 地图中人流集中的网格点坐标
        self.ban_list = []  # 地图中不该有人的网格点坐标
        self.normal_list = []   # 地图中其他的网格点坐标
        self.dummy_list = []  # 生成的虚拟轨迹列表（多个虚拟轨迹）
        self.InitMap()
        self.dummy_points = DummyPoints(7, min_X=0.1, max_X=1, min_Y=0.1, max_Y=1)

    def InitMap(self):
        """
        初始化地图（实际是网格标记及标记列表，根据真实地图情况人工标记）
        :return: None
        """
        self.hot_list = []
        self.ban_list = []
        self.normal_list = []
        for i in range(100):
            for j in range(100):
                self.normal_list.append((i, j))
        self.dummy_list = []

    def GetRegionType(self, x, y):
        """
        获取坐标所在网格点类型
        :param x: x坐标
        :param y: y坐标
        :return: 0:热点区域 1:禁止区域 2:一般区域
        """
        x = (x - self.x_min) // self.grid_size
        y = (y - self.y_min) // self.grid_size
        if (x, y) in self.hot_list:
            return 0
        elif (x, y) in self.ban_list:
            return 1
        else:
            return 2

    def Judge(self, x, y):
        return self.dummy_points.TryAddPoint(x, y)

    def OutOfBound(self, x, y):
        """
        坐标点是否超出地图规定的范围
        :param x: x坐标
        :param y: y坐标
        :return: 是/否超出地图范围
        """
        if self.x_min < x < self.x_max and self.y_min < y < self.y_max:
            return False
        else:
            return True

    def ChooseByPriority(self, candidates):
        """
        根据优先级在候选列表中抽取位置点
        把候选点按所在区域类型分为三类，若优先级高的类别存在元素则从中随机抽取，否则在低一级的优先级抽取
        :param candidates: 候选列表[(x1, y1), (x2, y2), ...]
        :return: 选择好的(x, y)
        """
        hot = []
        normal = []
        ban = []

        for point in candidates:
            point_type = self.GetRegionType(point[0], point[1])
            if point_type == 0:
                hot.append(point)
            elif point_type == 1:
                normal.append(point)
            elif point_type == 2:
                ban.append(point)

        if len(hot) != 0:
            x, y = random.choice(hot)
        else:
            if len(normal) != 0:
                x, y = random.choice(normal)
            else:
                x, y = random.choice(ban)

        return x, y

    def OutboundFind(self, x_range_min, x_range_max, y_range_min, y_range_max):
        """
        出界寻找，MN算法确定一个矩形范围，若其中无可选坐标点则可扩大一圈寻找
        :param x_range_min, x_range_max, y_range_min, y_range_max: 矩形范围参数
        :return: 扩大的圈中被虚拟轨迹检测算法判断为可选的点 [(x1,y1), (x2,y2), ...]
        """
        xy_list = []
        x_range_min = x_range_min - self.grid_size
        x_range_max = x_range_max + self.grid_size
        y_range_min = y_range_min - self.grid_size
        y_range_max = y_range_max + self.grid_size

        x_list = range(x_range_min, x_range_max, self.grid_size)
        for x in x_list:
            xy_list.append((x, y_range_min))  # 最下面的一行网格
            xy_list.append((x, y_range_max))  # 最上面的一行网格

        y_list = range(y_range_min, y_range_max, self.grid_size)[1:-1]
        for y in y_list:
            xy_list.append((x_range_min, y))  # 最左面的一行网格
            xy_list.append((x_range_max, y))  # 最右面的一行网格

        xy_list_bound = []
        for point in xy_list:
            if not self.OutOfBound(point[0], point[1]):  # 没有超出地图范围
                xy_list_bound.append(point)

        candidate = []
        for point in xy_list_bound:
            if self.Judge(point[0], point[1]):
                candidate.append(point)

        return candidate

    def InitDummyStart(self):
        """
        初始化虚拟轨迹，即对应当生成的每条虚拟轨迹添加一个随机起点
        :return: 起点坐标(x,y)
        """
        point = random.choice(self.normal_list + self.hot_list)  # 随机选一个网格
        x = self.x_min + point[0] * self.grid_size + random.uniform(0, self.grid_size)
        y = self.y_min + point[1] * self.grid_size + random.uniform(0, self.grid_size)
        # self.dummy_list.append((x, y))
        return x, y

    def Generate(self, m, length):
        """
        生成虚拟轨迹
        :param m: MN算法中的m，衡量某点的下一点可能存在的范围大小
        :param length: 欲生成的虚拟轨迹的长度
        :return: None, 直接修改self.dummy_list
        """
        # 先生成两个点
        x_0, y_0 = self.InitDummyStart()  # 生成第一个点
        self.dummy_list.append((x_0, y_0))
        self.dummy_points.TryAddPoint(x_0, y_0)

        x_2, y_2 = 0, 0
        flag = 0
        for i in range(100):  # 生成第二个点, 最多尝试100次
            x_2 = min(max(random.uniform(self.dummy_list[0][0] - m, self.dummy_list[0][0] + m), self.x_min), self.x_max)
            y_2 = min(max(random.uniform(self.dummy_list[0][1] - m, self.dummy_list[0][1] + m), self.y_min), self.y_max)
            if self.GetRegionType(x_2, y_2) != 1:
                flag = 1  # 生成成功
                break
        if flag:
            self.dummy_list.append((x_2, y_2))
            self.dummy_points.TryAddPoint(x_2, y_2)
        else:
            point = random.choice(self.normal_list + self.hot_list)  # 随机选一个网格
            x = self.x_min + point[0] * self.grid_size + random.uniform(0, self.grid_size)
            y = self.y_min + point[1] * self.grid_size + random.uniform(0, self.grid_size)
            self.dummy_list.append((x, y))
            self.dummy_points.TryAddPoint(x_2, y_2)

        # 主要逻辑，先用MN算法生成点，然后用分类器检测
        point_index = 1  # 当前最后一个点的下标（初始时有两个点，index从0开始，因此当前最后一个点index=1）
        while True:
            if point_index >= length:
                break
            x1 = self.dummy_list[point_index - 1][0]
            y1 = self.dummy_list[point_index - 1][1]
            # 这里的x2，y2指当前最后的位置点，因为计算各类信息至多需要3个点，其中第3个是待添加的位置点，第2个是当前最后的位置点
            x2 = self.dummy_list[point_index][0]
            y2 = self.dummy_list[point_index][1]

            x_range_min = max((x2 - m) // self.grid_size, 0) + 0.5 * self.grid_size
            x_range_max = min((x2 + m) // self.grid_size, self.grid_num - 1) + 0.5 * self.grid_size
            x_list = (np.arange(x_range_min, x_range_max + 0.001, self.grid_size)).tolist()
            y_range_min = max((y2 - m) // self.grid_size, 0) + 0.5 * self.grid_size
            y_range_max = min((y2 + m) // self.grid_size, self.grid_num - 1) + 0.5 * self.grid_size
            y_list = (np.arange(y_range_min, y_range_max + 0.001, self.grid_size)).tolist()
            xy_list = []  # MN算法范围内所有可选点
            for x in x_list:
                for y in y_list:
                    xy_list.append((x, y))

            candidate = []  # MN算法范围内，被检测为真实轨迹的点
            for x3, y3 in xy_list:
                if self.Judge(x3, y3):
                    candidate.append((x3, y3))
            if not candidate:  # 无可行点，出界一圈寻找
                candidate = self.OutboundFind(x_range_min, x_range_max, y_range_min, y_range_max)
                if not candidate:  # 出圈寻找仍然无效，在MN算法确定范围内随机选一点
                    x, y = self.ChooseByPriority(xy_list)
                    self.dummy_list.append((x, y))
                    self.dummy_points.AddPoint(x, y)
                else:  # 出圈寻找有效，在candidate中随机选一点
                    x, y = self.ChooseByPriority(candidate)
                    self.dummy_list.append((x, y))
                    self.dummy_points.AddPoint(x, y)
            else:  # 有可行点，在candidate中随机选一点
                x, y = self.ChooseByPriority(candidate)
                self.dummy_list.append((x, y))
                self.dummy_points.AddPoint(x, y)

            point_index += 1


if __name__ == "__main__":
    map = Map(0, 100, 0, 100, 100)
    map.Generate(0.5, 5)
    print()
    print(map.dummy_list)
    print("结束")

