"""
使用MN算法生成虚拟轨迹并绘制图像
"""
import random
import numpy as np
from ShowTrajs import DrawRealTraj
import matplotlib.pyplot as plt


class DummyPoint:
    def __init__(self, lng=0, lat=0, t=0):
        """
        虚拟轨迹点
        :param lng: 经度
        :param lat: 纬度
        :param t:时间戳
        """
        self.lng = lng
        self.lat = lat
        self.t = t

    def WithinBounds(self, max_lng, min_lng, max_lat, min_lat):
        """
        该点是否在规定区域内
        :return: 是或否
        """
        if min_lat <= self.lat <= max_lat and min_lng <= self.lng <= max_lng:
            return True
        return False


def MovingInNeighborhood(m, n, with_t, max_lng, min_lng, max_lat, min_lat):
    """
    生成一条虚拟轨迹
    :param m: 每次移动的幅度
    :param n: 轨迹长度（轨迹点数）
    :param with_t: 是否生成时间维度
    :param max_lng, min_lng, max_lat, min_lat: 生成轨迹点的限制范围
    :return: 虚拟轨迹
    """

    dummyNexttemp = DummyPoint()  # 后一时刻用户位置及时间信息
    dummyNexttemp.lng = random.uniform(min_lng, max_lng)
    dummyNexttemp.lat = random.uniform(min_lat, max_lat)
    if with_t:
        dummy = [[dummyNexttemp.lat, dummyNexttemp.lng, random.randint(0, 24 * 3600)]]  # 初始状态，轨迹列表只有初始点
    else:
        dummy = [[dummyNexttemp.lat, dummyNexttemp.lng]]  # 初始状态，轨迹列表只有初始点（删除时间维度）

    i = 0
    num_errors = 50  # 有时候出界后回不去，这种状态最多卡死num_errors次，就会随机选择一个位置跳出
    dummyPretemp = dummyNexttemp  # 前一时刻用户位置及时间信息（这里初始化）
    while i < n - 1:
        # 生成下一位置及时间信息
        dummyNexttemp.lng = random.uniform(dummyPretemp.lng - m, dummyPretemp.lng + m)
        dummyNexttemp.lat = random.uniform(dummyPretemp.lat - m, dummyPretemp.lat + m)
        dummyNexttemp.t = dummyPretemp.t + random.randint(17, 22)  # 计时方法
        if dummyNexttemp.WithinBounds(max_lng, min_lng, max_lat, min_lat):  # 在规定区域内才添加到列表，否则重新生成
            dummyPretemp = dummyNexttemp
            if with_t:
                dummy.append([dummyNexttemp.lat, dummyNexttemp.lng, dummyNexttemp.t])
            else:
                dummy.append([dummyNexttemp.lat, dummyNexttemp.lng])  # 删除时间维度
            i = i + 1
        else:  # 如果一直发生越界错误就随机找一个点（该情况存在但极少）
            if num_errors > 0:
                num_errors -= 1
            else:
                lng = random.uniform(min_lng, max_lng)
                lat = random.uniform(min_lat, max_lat)
                if with_t:
                    dummy.append([lat, lng, dummyNexttemp.t])
                else:
                    dummy.append([lat, lng])  # 删除时间维度
                num_errors = 50

    return dummy


def Draw(dummy, max_lng, min_lng, max_lat, min_lat):
    """
    绘制虚拟轨迹
    :param dummy: 虚拟轨迹(列表格式)
    """
    plt.figure()
    plt.xlabel('Lng')
    plt.ylabel('Lat')
    plt.xlim(xmax=max_lng, xmin=min_lng)
    plt.ylim(ymax=max_lat, ymin=min_lat)
    color1 = '#FF0000'
    color2 = '#00FF00'
    area = np.pi * 4**2  # 点面积
    # 画折线图
    x = [i[1] for i in dummy]
    y = [i[0] for i in dummy]
    plt.plot(x, y)
    # 画起点、终点
    plt.scatter([x[0]], [y[0]], s=area, c=color1, alpha=1, label="起点")
    plt.scatter([x[-1]], [y[-1]], s=area, c=color2, alpha=1, label="终点")
    plt.legend()
    plt.show()


if __name__ == '__main__':
    dummy = MovingInNeighborhood(m=0.0001, n=100, with_t=False,
                                 max_lng=116.5728, min_lng=116.1715, max_lat=40.1075, min_lat=39.7871)  # 生成单条轨迹
    print(dummy)
    print("length of dummy: ", len(dummy))

    max_value = list(map(max, *dummy))
    min_value = list(map(min, *dummy))
    print("max_lat: ", max_value[0], "  max_lng: ", max_value[1])
    print("min_lat: ", min_value[0], "  min_lng: ", min_value[1])

    DrawRealTraj.Draw(dummy, xmax=max_value[1], xmin=min_value[1], ymax=max_value[0], ymin=min_value[0])
