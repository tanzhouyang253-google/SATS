import random


def GenerateRandomTrajs(num_trajs, len_trajs, with_t, max_lng, min_lng, max_lat, min_lat):
    trajs = []
    for i in range(num_trajs):
        traj = []
        t = random.randint(0, 24 * 60 * 60)
        for j in range(len_trajs):
            point_lat = min_lat + random.random() * (max_lat - min_lat)
            point_lng = min_lng + random.random() * (max_lng - min_lng)
            t += 2
            if with_t:
                traj.append([point_lat, point_lng, t])
            else:
                traj.append([point_lat, point_lng])
        trajs.append(traj)
    return trajs


if __name__ == "__main__":
    dummys = GenerateRandomTrajs(5, 10, with_t=True, max_lng=116.5728, min_lng=116.1715, max_lat=40.1075, min_lat=39.7871)
    print(dummys)