import math


def CoordConvert(lat, lng, min_lat, min_lng):
    """
    将经纬度用mercator投影转换为平面直角坐标系坐标，再转换为关于所选范围左下角的相对坐标
    :param lat: 纬度
    :param lng: 经度
    :param min_lat: 目标范围最小纬度
    :param min_lng: 目标范围最小经度
    :return: 转换后的坐标
    """
    R = 6378137  # 地球半径，单位为米
    x = R * math.radians(lng)
    scale1 = math.tan(math.radians(45 + lat / 2))
    y = R * math.log(scale1)

    x_min = R * math.radians(min_lng)
    scale2 = math.tan(math.radians(45 + min_lat / 2))
    y_min = R * math.log(scale2)

    x = x - x_min
    y = y - y_min
    return x, y


def mercator(lat, lng):
    """
    不做做相对变换的mercator投影坐标转换法
    :param lat: 纬度
    :param lng: 经度
    :return:
    """
    R = 6378137  # 地球半径，单位为米
    x = R * math.radians(lng)
    scale = math.tan(math.radians(45 + lat / 2))
    y = R * math.log(scale)
    return x, y
