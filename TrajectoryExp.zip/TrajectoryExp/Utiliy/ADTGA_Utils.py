"""
读取Geolife数据集,数据预处理，编码，工具函数等
"""
import math
import os
import pickle
import random
import torch
import matplotlib.pyplot as plt
from DummyTrajsGenerate import MLNAlgorithm, MNAlgorithm, ADTGAAlgorithm
from DummyTrajsGenerate.RandomAlgorithm import GenerateRandomTrajs
from Utiliy import CoordSysConv
from Utiliy.Utils import WithinBounds, ParseTime, CalDist, VectorUnitize, CalMedian, VecToAngle, CalAverage, \
    GetDataWithBound

GetDataWithBound# 纬度范围
minLat = 39.7817
maxLat = 40.1075
# 经度范围
minLng = 116.1715
maxLng = 116.5728

# # 纬度范围
# minLat = 39.85
# maxLat = 40.05
# # 经度范围
# minLng = 116.2
# maxLng = 116.5

# 网格维度
gridSize = 256


def GenerateDummyTrajectory(n, id, mode):
    """
    生成多条符合一定格式的虚拟轨迹，并返回编码后的结果
    :param n: 生成虚拟轨迹的条数
    :return: 虚拟轨迹特征，元素为(M, Ind)的list
    """
    if mode == "MN":
        trajs_feature = []
        for i in range(n):  # 生成x条轨迹
            dummy_traj = MNAlgorithm.MovingInNeighborhood(m=0.0001, n=800, with_t=True,
                                                          max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)  # 生成单条轨迹
            # 单条轨迹处理
            M = EncodeTrajWithIT2I(dummy_traj)
            Ind = EncodeInd(dummy_traj)
            trajs_feature.append([M, Ind])
    if mode == "MLN":
        trajs_feature = []
        otherLocations = MLNAlgorithm.GetOtherLocations(id=id, with_t=True, convert=False, max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)
        for i in range(n):  # 生成x条轨迹
            print(i)
            dummy_traj = MLNAlgorithm.MovingInNeighborhood(aveP=10, m=0.0001, n=800, otherLocations=otherLocations,
                                                           with_t=True, max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)  # 生成单条轨迹
            # 单条轨迹处理
            M = EncodeTrajWithIT2I(dummy_traj)
            Ind = EncodeInd(dummy_traj)
            trajs_feature.append([M, Ind])
    if mode == "Random":
        dummys = GenerateRandomTrajs(n, 800, with_t=True, max_lng=maxLng, min_lng=minLng, max_lat=maxLat, min_lat=minLat)
        trajs_feature = []
        for i in range(len(dummys)):
            M = EncodeTrajWithIT2I(dummys[i])
            Ind = EncodeInd(dummys[i])
            trajs_feature.append([M, Ind])
    if mode == "ADTGA":
        # pickle_file = open('../ADTGA_Data.pkl', 'rb')
        # real_data, adtga_dummys = pickle.load(pickle_file)
        real_data, adtga_data = ADTGAAlgorithm.GetDataByADTGA(id, k_metric=0.5, tsd_metric=0.3, tdd_metric=0.003, ld_metric=0.3)
        real_data = real_data[:n]
        adtga_data = adtga_data[:n]

        real_traj_feature_list = []
        for i in range(len(real_data)):
            M = EncodeTrajWithIT2I(real_data[i])
            Ind = EncodeInd(real_data[i])
            real_traj_feature_list.append([M, Ind])
        dummy_traj_feature_list = []
        for i in range(len(adtga_data)):
            M = EncodeTrajWithIT2I(adtga_data[i])
            Ind = EncodeInd(adtga_data[i])
            dummy_traj_feature_list.append([M, Ind])
        return real_traj_feature_list, dummy_traj_feature_list

    return trajs_feature


def GetCellID(lat, lng):
    """
    根据经纬度获得网格编码id
    :param lat: 位置点纬度
    :param lng: 位置点经度
    :return: 返回 0 <= x, y < 256
    """
    x_step = (maxLng - minLng) / gridSize
    x = int((lng - minLng) // x_step)
    y_step = (maxLat - minLat) / gridSize
    y = int((lat - minLat) // y_step)
    # 边界情况
    if x >= 256:
        x = 255
    if y >= 256:
        y = 255
    return x, y  # 经，纬


def EncodeTrajWithIT2I(data):
    """
    轨迹iT2I编码
    :param data: 二维列表表示的轨迹数据，第1维表示轨迹中的位置点数目，第2维表示纬度和经度
    :return: 编码后的 5 * gridSize * gridSize 的矩阵组成的tensor
    """
    m_i1 = [[0 for j in range(gridSize)] for i in range(gridSize)]  # 是否有位置点
    m_i2 = [[0 for j in range(gridSize)] for i in range(gridSize)]  # 时间
    m_i3 = [[0 for j in range(gridSize)] for i in range(gridSize)]  # 速度
    m_i4 = [[0 for j in range(gridSize)] for i in range(gridSize)]  # 方向
    m_i5 = [[0 for j in range(gridSize)] for i in range(gridSize)]  # 加速度

    # 第一次遍历构造m_i1和m_i2 (一个路径遍历和一个网格遍历)
    num_cell_points = [[0 for i in range(gridSize)] for i in range(gridSize)]
    for point in data:
        x, y = GetCellID(point[0], point[1])  # 返回的是lat, lng
        num_cell_points[x][y] += 1
        m_i1[x][y] = 1
        m_i2[x][y] += point[2]  # 时间
    for i in range(gridSize):
        for j in range(gridSize):
            if num_cell_points[i][j] != 0:  # 网格有点则取时间平均值
                m_i2[i][j] = m_i2[i][j] / num_cell_points[i][j]

    # 第二次循环构造m_i3,m_i4,m_i5
    cell_speed_list = [[[] for i in range(gridSize)] for i in range(gridSize)]  # 每个网格里的速度值，最后需要求中位数
    cell_direction_list = [[[] for i in range(gridSize)] for i in range(gridSize)]  # 每个网格里的方向值，最后需要求平均数
    cell_acceleration_list = [[[] for i in range(gridSize)] for i in range(gridSize)]  # 每个网格里的加速度值，最后需要求中位数
    first_point = True  # 由于第一个点的速度和加速度都直接初始化为0，所以处理方式和其他点有区别
    last_speed = 0  # 上一个点的速度
    for point_id in range(len(data)):
        x, y = GetCellID(data[point_id][0], data[point_id][1])
        if first_point:
            # m_i3[x][y] = 0
            # m_i4[x][y] = 0
            # m_i5[x][y] = 0
            last_speed = 0
            first_point = False
        else:
            delta_t = data[point_id][2] - data[point_id - 1][2]  # 该点与上一点的时间差
            if delta_t == 0:  # 跳过重复点
                continue
            speed = CalDist(data[point_id], data[point_id - 1]) / delta_t  # 该点速度
            direction = VectorUnitize([data[point_id][0] - data[point_id - 1][0],
                                       data[point_id][1] - data[point_id - 1][1]])  # 该点前进方向
            acceleration = (speed - last_speed) / delta_t  # 该点加速度
            cell_speed_list[x][y].append(speed)  # 添加到网格速度列表
            cell_direction_list[x][y].append(direction)  # 添加到网格方向列表
            cell_acceleration_list[x][y].append(acceleration)  # 添加到网格加速度列表
            last_speed = speed  # 更新上一个点的速度

    # 更新3D矩阵
    for i in range(gridSize):
        for j in range(gridSize):
            if num_cell_points[i][j] == 0:  # 网格无点则保持为0
                pass
            else:  # 网格有点则取速度和加速度的中值，方向的平均值
                m_i3[i][j] = CalMedian(cell_speed_list[i][j])
                m_i4[i][j] = VecToAngle(CalAverage(cell_direction_list[i][j]))
                m_i5[i][j] = CalMedian(cell_acceleration_list[i][j])

    M = [m_i1, m_i2, m_i3, m_i4, m_i5]
    M = torch.tensor(M, dtype=torch.float32)

    return M


def EncodeInd(data):
    """
    编码个体特征
    :param data: 二维列表表示的轨迹数据，第1维表示轨迹中的位置点数目，第2维表示纬度和经度
    :return: 编码后的含4个元素的向量，分别为轨迹距离、总用时、起始时间、平均速度
    """
    distance = 0
    for i in range(1, len(data)):
        distance += CalDist(data[i], data[i - 1])
    total_time = data[-1][2] - data[0][2]
    start_time = data[0][2]
    avg_speed = distance / total_time
    return torch.tensor([distance, total_time, start_time, avg_speed], dtype=torch.float32)


if __name__ == '__main__':

    print(CalDist((39.984653, 116.311189),()))
    exit(0)
    user_id = "052"
    data = GetDataWithBound(user_id, False, minLat, maxLat, minLng, maxLng)
    # print(len(data))
    file_name = "data/BoundData/points_128.js"
    # TrajShowScript.WriteSingleScript(file_name, data)
    exit(0)
