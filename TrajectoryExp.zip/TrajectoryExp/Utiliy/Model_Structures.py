import torch
from torch import nn
from torch.nn import functional as F


class LSTM(nn.Module):
    """
    虚拟轨迹识别的LSTM方法
    """
    def __init__(self, input_size, hidden_size, num_layers, num_classes, device):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, num_classes)
        self.softmax = nn.Softmax(dim=1)
        self.device = device

    def forward(self, x):
        # 初始化隐藏层和细胞状态
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(self.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(self.device)
        out, _ = self.lstm(x, (h0, c0))  # out: tensor of shape (batch_size, seq_length, hidden_size)
        out = self.fc(out[:, -1, :])  # 此处的-1说明我们只取RNN最后输出的那个hn
        out = self.softmax(out)
        return out


class CNN(nn.Module):
    """
    虚拟轨迹识别的LSTM方法
    """
    def __init__(self, len_sec, hidden_size, num_classes, alpha):
        super(CNN, self).__init__()
        self.len_sec = len_sec
        self.hidden_size = hidden_size
        self.num_classes = num_classes
        self.alpha = alpha
        self.ft_conv_list = []
        self.ft_pool_list = []
        for i in range(len_sec):
            self.ft_conv_list.append(nn.Conv1d(2, 128, (3), padding=1))
            self.ft_pool_list.append(nn.MaxPool1d(i+1))

        self.rt_conv_list = []
        self.rt_pool_list = []
        for i in range(len_sec):
            self.rt_conv_list.append(nn.Conv1d(2, 128, (3), padding=1))
            self.rt_pool_list.append(nn.MaxPool1d(i+1))

        self.fc1 = nn.Linear(self.len_sec * 128, hidden_size)
        self.fc2 = nn.Linear(hidden_size, num_classes)

        self.softmax = nn.Softmax(dim=1)

    def forward(self, ft, rt):
        batch_size = ft.size(0)
        # 计算ft相关数据
        ft_conv_out_list = []
        for i in range(self.len_sec):
            ft_i = ft[:, :, :i + 1]
            ft_conv_out_i = self.ft_conv_list[i](ft_i)
            ft_pool_out_i = self.ft_pool_list[i](ft_conv_out_i)
            ft_conv_out_list.append(ft_pool_out_i)

        # 连接ft的所有out_i
        ft_connected_out = torch.cat(ft_conv_out_list, dim=1).reshape(batch_size, -1)
        ft_fc_out = self.fc1(ft_connected_out)
        ft_fc_out = self.fc2(ft_fc_out)
        ft_softmax_out = self.softmax(ft_fc_out)

        # 计算rt相关数据
        rt_conv_out_list = []
        for i in range(self.len_sec):
            rt_i = rt[:, :, :i + 1]
            rt_conv_out_i = self.rt_conv_list[i](rt_i)
            rt_pool_out_i = self.rt_pool_list[i](rt_conv_out_i)
            rt_conv_out_list.append(rt_pool_out_i)

        # 连接rt的所有out_i
        rt_connected_out = torch.cat(ft_conv_out_list, dim=1).reshape(batch_size, -1)
        rt_fc_out = self.fc1(rt_connected_out)
        rt_fc_out = self.fc2(rt_fc_out)
        rt_softmax_out = self.softmax(rt_fc_out)

        out = self.alpha * ft_softmax_out + (1 - self.alpha) * rt_softmax_out
        # print("out", out)

        return out


class TSHN(nn.Module):
    """
    神经网络结构
    """
    def __init__(self):
        super(TSHN, self).__init__()
        # 1. 对5D矩阵的卷积处理和打平部分
        self.conv1 = nn.Sequential(     # (5, 256, 256)
            nn.Conv2d(5, 5, 2, 2, 0),   # (5, 128, 128)  params: in_channels, out_channels, kernel_size, stride, padding
            nn.ReLU(),
            nn.MaxPool2d(2)             # (5, 64, 64)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(5, 5, 2, 2, 0),   # (5, 32, 32)
            nn.ReLU(),
            nn.MaxPool2d(2)             # (5, 16, 16)
        )
        self.fc1 = nn.Linear(5 * 16 * 16, 512)
        self.fc2 = nn.Linear(512, 128)

        # 2. 对5维向量的全连接层部分
        self.fc3 = nn.Linear(4, 16)
        self.fc4 = nn.Linear(16, 4)

        # 3. 1和2的结果向量合并部分
        self.combine = nn.Linear(132, 32)  # 128 + 4
        self.fc5 = nn.Linear(32, 1)

    def forward(self, x, y):
        #print(x)
        #print(y.shape)
        # 1. 对5D矩阵的卷积处理和打平部分
        x = self.conv1(x)
        x = self.conv2(x)
        x = x.view(x.size(0), -1)
        # x = F.dropout(x, p=0.5)
        x = self.fc1(x)
        x = F.relu(x)
        x = F.dropout(x, p=0.5)
        x = self.fc2(x)
        x = F.relu(x)
        #print(x)

        # 2. 对5维向量的全连接层部分
        y = self.fc3(y)
        y = F.relu(y)
        #print(x)
        y = self.fc4(y)
        y = F.relu(y)

        # 3. 1和2的结果向量合并部分
        xy = torch.cat((x, y), dim=1)
        xy = self.combine(xy)
        xy = F.relu(xy)
        # xy = F.dropout(xy, p=0.5)
        output = self.fc5(xy)
        return output.squeeze(-1)


class TSHN_Extend(nn.Module):
    """
    神经网络结构
    """
    def __init__(self):
        super(TSHN_Extend, self).__init__()
        # 1. 对5D矩阵的卷积处理和打平部分
        self.conv1 = nn.Sequential(     # (5, 256, 256)
            nn.Conv2d(5, 5, 2, 2, 0),   # (5, 128, 128)  params: in_channels, out_channels, kernel_size, stride, padding
            nn.ReLU(),
            nn.MaxPool2d(2)             # (5, 64, 64)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(5, 5, 2, 2, 0),   # (5, 32, 32)
            nn.ReLU(),
            nn.MaxPool2d(2)             # (5, 16, 16)
        )
        self.fc1 = nn.Linear(5 * 16 * 16, 512)
        self.fc2 = nn.Linear(512, 128)

        # 2. 对5维向量的全连接层部分
        self.fc3 = nn.Linear(4, 16)
        self.fc4 = nn.Linear(16, 4)

        # 3. 1和2的结果向量合并部分
        self.combine1 = nn.Linear(132, 32)  # 128 + 4
        self.combine2 = nn.Linear(64, 32)
        self.fc5 = nn.Linear(32, 1)
        # self.fc5 = nn.Linear(32, 2)

    def forward(self, x1, y1, x2, y2):
        # 对第一组数据
        # 1. 对5D矩阵的卷积处理和打平部分
        x1 = self.conv1(x1)
        x1 = self.conv2(x1)
        x1 = x1.view(x1.size(0), -1)
        x1 = self.fc1(x1)
        x1 = F.relu(x1)
        x1 = F.dropout(x1, p=0.5)
        x1 = self.fc2(x1)
        x1 = F.relu(x1)
        # 2. 对5维向量的全连接层部分
        y1 = self.fc3(y1)
        y1 = F.relu(y1)
        y1 = self.fc4(y1)
        y1 = F.relu(y1)
        # 3. 1和2的结果向量合并部分
        xy1 = torch.cat((x1, y1), dim=1)
        xy1 = self.combine1(xy1)
        xy1 = F.relu(xy1)

        # 对第二组数据
        # 1. 对5D矩阵的卷积处理和打平部分
        x2 = self.conv1(x2)
        x2 = self.conv2(x2)
        x2 = x2.view(x2.size(0), -1)
        x2 = self.fc1(x2)
        x2 = F.relu(x2)
        x2 = F.dropout(x2, p=0.5)
        x2 = self.fc2(x2)
        x2 = F.relu(x2)
        # 2. 对5维向量的全连接层部分
        y2 = self.fc3(y2)
        y2 = F.relu(y2)
        y2 = self.fc4(y2)
        y2 = F.relu(y2)
        # 3. 1和2的结果向量合并部分
        xy2 = torch.cat((x2, y2), dim=1)
        xy2 = self.combine1(xy2)
        xy2 = F.relu(xy2)

        # 合并两组数据
        # xy1xy2 = torch.cat((xy1, xy2), dim=1)
        # xy1xy2 = self.combine2(xy1xy2)
        xy1xy2 = torch.abs(torch.sub(xy1, xy2))
        output = self.fc5(xy1xy2)
        # output = torch.sigmoid(output)
        # output = torch.softmax(output, dim=1)

        return output.squeeze(-1)



if __name__ == "__main__":
    model = TSHN_Extend()
    x1 = torch.rand(8, 5, 256, 256)
    y1 = torch.rand(8, 4)
    x2 = torch.rand(8, 5, 256, 256)
    y2 = torch.rand(8, 4)

    output = model(x1, y1, x2, y2)
    print(output)
    # len_sec = 5
    # batch_size = 1
    # num_classes = 2
    # hidden_size = 128
    # model = CNN(len_sec, hidden_size, num_classes, 0.5)
    #
    # ft = torch.randn(2, 5, 2)
    # ft = torch.permute(ft, (0, 2, 1))
    # print("ft", ft)
    # rt = torch.randn(2, 5, 2)
    # rt = torch.permute(rt, (0, 2, 1))
    # out = model(ft, rt)
    # # print(ft)
    # # print(ft.shape)
    # # print(ft[:, :, :1])
    # # print(ft[:, :, :1].shape)
    #
    # exit()
    # import torch
    # from torch.nn import Conv1d
    #
    # # 定义一个一维卷积，输入通道大小为5，输出通道大小为2，卷积核宽度为4
    # conv1 = Conv1d(5, 2, 4)
    # # 再定义一个一维卷积，输入通道大小为5，输出通道大小为2，卷积核宽度为3
    # conv2 = Conv1d(5, 2, 3)
    #
    # # 输入数据批次大小为2，即有两个序列，每个序列长度为6，每个输入的维度为5
    # inputs = torch.rand(1, 5, 6)
    #
    # outputs1 = conv1(inputs)
    # outputs2 = conv2(inputs)
    # print(outputs1)
    # print(outputs2)
    # print(outputs1.shape)
    # print(outputs2.shape)
    #
    # from torch.nn import MaxPool1d
    # pool1 = MaxPool1d(3)  # 第一个池化层核的大小为3，即卷积层的输出序列长度
    # pool2 = MaxPool1d(4)  # 第二个池化层核的大小为4，即卷积层的输出序列长度
    #
    # # 执行一维最大池化操作，即取每行输入的最大值
    # outputs_pool1 = pool1(outputs1)
    # outputs_pool2 = pool2(outputs2)
    # print(outputs_pool1)
    # print(outputs_pool2)
    # print(outputs_pool1.shape)
    # print(outputs_pool2.shape)
