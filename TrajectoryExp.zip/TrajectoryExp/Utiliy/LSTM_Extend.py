import math
import torch
from torch import nn


def CalRoa(x1, y1, x2, y2, x3, y3):
    """
    计算roa角度:《Deep Learning-Based Virtual Trajectory Generation Scheme》
    :param x1,y1, x2,y2, x3,y3: 最近三个点的坐标
    :return: roa角度大小（弧度制）
    """
    vec_a = ((y2 - y1), (x2 - x1))
    vec_b = ((y3 - y2), (x3 - x2))
    vec_a_len = math.sqrt(vec_a[0] ** 2 + vec_a[1] ** 2)
    vec_b_len = math.sqrt(vec_b[0] ** 2 + vec_b[1] ** 2)
    a_dot_b = vec_a[0] * vec_b[0] + vec_a[1] * vec_b[1]
    is_below = False

    if x2 != x1:
        k = (y2 - y1) / (x2 - x1)
        b = y1 - k * x1
        tmp_y = k * x3 + b
        if y3 < tmp_y:
            is_below = True

    cos = a_dot_b / ((vec_a_len * vec_b_len) + 1e-10)
    cos = min(cos, 1)
    cos = max(cos, -1)

    if is_below:
        roa = math.acos(cos)
    else:
        roa = -1 * math.acos(cos)
    return roa / math.pi


def CalRl(x1, y1, x2, y2, total_dist):
    """
    计算轨迹段相对长度:《Deep Learning-Based Virtual Trajectory Generation Scheme》
    :param x1,y1, x2,y2: 最近两个点坐标
    :param total_dist: 轨迹总长度(不算待添加的点)
    :return: 相对长度值
    """
    seq_dist = math.sqrt((y2 - y1) ** 2 + (x2 - x1) ** 2)
    rl = seq_dist / (total_dist + seq_dist)
    return rl


def SeqToBatches(seq, k):
    """
    把轨迹点(四元组)列表转化为多个轨迹点组成的列表
    :param seq: 轨迹点列表[[a,b,c,d], [a,b,c,d], ...]
    :param k: 轨迹段长度
    :return: torch.tensor((batch_num, k, 4))
    """
    # seq = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [1, 2, 3, 4]]
    length = len(seq)
    batch_num = length // k
    input = []
    for i in range(batch_num):
        input.append([])
        for j in range(k):
            input[-1].append(seq[i * k + j])
    input = torch.FloatTensor(input)

    return input


def CalDist(x1, y1, x2, y2):
    """
    计算两点间距离
    :param x1,y1, x2,y2:
    :return: 两点间距离
    """
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)


class LSTM(nn.Module):
    """
    虚拟轨迹识别的LSTM方法
    """

    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, num_classes)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        # 初始化隐藏层和细胞状态
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device)
        out, _ = self.lstm(x, (h0, c0))  # out: tensor of shape (batch_size, seq_length, hidden_size)
        out = self.fc(out[:, -1, :])  # 此处的-1说明我们只取RNN最后输出的那个hn
        out = self.softmax(out)
        return out


# 超参数
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
len_sections = 3  # 每个轨迹段的轨迹点数
input_size = 4  # 神经网络每个输入的大小，2表示一个经度一个纬度
hidden_size = 10  # 隐藏层单元数
num_layers = 1  # LSTM网络层数
num_classes = 2  # 类别数，只有真轨迹和假轨迹两类
batch_size = 8  # 批处理的每批数据量
num_epochs = 50  # 训练轮数
learning_rate = 0.0001  # 学习率
threshold = 0.5  # 判断一个轨迹真假的阈值，若真轨迹段的比例大于阈值则认为是真轨迹


class DummyPoints:
    """
    维护最近k个轨迹点信息(七元组[roa, rl, X, Y, x, y, l])
    调用self.TryAddPoint(x, y)增加点，self.data会自动维护
    """
    def __init__(self, k, min_X=0.1, max_X=1, min_Y=0.1, max_Y=1):
        """
        :param k: 虚拟轨迹段长度（实际是最大长度）
        :param min_X, max_X, min_Y, max_Y: 数据集中轨迹点的最值
        """
        self.k = k  # 轨迹段长度（实际是最大长度）
        self.start = 0  # 游标
        self.end = 0  # 游标
        self.min_X = min_X
        self.max_X = max_X
        self.min_Y = min_Y
        self.max_Y = max_Y
        self.data = []  # [[roa, rl, X, Y], [roa, rl, X, Y], ...]

    def CalAttrs(self, x, y):
        """
        对于一个新轨迹点，计算其信息(七元组[roa, rl, X, Y, x, y, l])
        调用该方法时self.data至少含两个点
        :param x, y: 新轨迹点
        :return:
        """
        length = self.end - self.start  # 现有轨迹点个数
        assert length >= 2
        if length < self.k:
            total_l = sum([self.data[i][6] for i in range(self.start, self.end)])
        else:
            assert length == self.k
            total_l = sum([self.data[i][6] for i in range(self.start + 1, self.end)])

        roa = CalRoa(self.data[-2][4], self.data[-2][5], self.data[-1][4], self.data[-1][5], x, y)
        X = x - self.data[-1][4]
        X = (X - self.min_X) / (self.max_X - self.min_X)
        Y = y - self.data[-1][5]
        Y = (Y - self.min_Y) / (self.max_Y - self.min_Y)
        l_n = CalDist(self.data[-1][4], self.data[-1][5], x, y)
        rl = CalRl(self.data[-1][4], self.data[-1][5], x, y, total_l)

        return [roa, rl, X, Y, x, y, l_n]

    def AddPoint(self, x, y):
        """
        在self.data中添加点(x,y)的属性
        注：通过此方法添加的点组成的轨迹段不一定被检测为真实轨迹
        注：只能添加第三个点及之后的点，因为前两点无法计算属性
        :return: None
        """
        assert self.end - self.start >= 2
        self.data.append(self.CalAttrs(x, y))
        self.end += 1
        if self.end - self.start >= self.k:
            self.start += 1

    def TryAddPoint(self, x, y):
        """
        尝试在self.data中添加点(x,y)是否满足检测结果要求
        :return: 是否可以添加
        """
        length = self.end - self.start  # 现有轨迹点个数
        if length == 0:  # 添加第一个点
            self.data.append([0, 0, 0, 0, x, y, 0])
            self.end += 1
        elif length == 1:  # 添加第二个点
            l_2 = CalDist(self.data[-1][4], self.data[-1][5], x, y)
            self.data.append([0, 1, 1, 1, x, y, l_2])
            self.end += 1

        else:  # 后面的点只检测，不添加
            attrs = self.CalAttrs(x, y)
            if self.detect(attrs[:4]):
                # self.data.append([roa, rl, X, Y, x, y, l_n])
                # self.end += 1
                # if self.end - self.start > self.k:
                #     self.start += 1
                # assert self.end - self.start <= self.k
                return True
            else:
                return False

    def detect(self, new_data):
        if self.end - self.start < self.k:
            seq = [self.data[i][:4] for i in range(self.start, self.end)]
        else:
            seq = [self.data[i][:4] for i in range(self.start + 1, self.end)]
        seq.append(new_data)
        input = torch.FloatTensor(seq).unsqueeze(0)
        # print(input)

        with torch.no_grad():
            out = model(input)
            # out = torch.max(out, dim=1)
            # out = torch.sum(out[1]).item()
            # print(out)
            print(torch.max(out, dim=1)[1].item())
        if torch.max(out, dim=1)[1].item():
            return True
        else:
            return False


# model = LSTM(input_size, hidden_size, num_layers, num_classes).to(device)
model = torch.load("/Users/zhangwenbo/Documents/研究生资料/代码/TrajectoryExp/LSTM_Model.pkl")
# criterion = nn.CrossEntropyLoss()
# optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

if __name__ == '__main__':
    secs = torch.randn((10, 3, 4))
    out = model(secs)
    print(out)
    print(out.shape)
    # input = SeqToBatchs(2)
    # print(input)
    # print(input.shape)

    # dummys_points = DummyPoints(3)
    # dummys_points.AddPoint(1, 1)
    # dummys_points.AddPoint(2, 2)
    # dummys_points.AddPoint(3, 3)
    # dummys_points.AddPoint(4, 4)
    # dummys_points.AddPoint(5, 5)
    # print(dummys_points.data)
    # exit()


