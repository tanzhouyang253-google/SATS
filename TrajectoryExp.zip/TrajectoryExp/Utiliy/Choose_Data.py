import re
import os

from ShowTrajs.TrajShowScript import WriteSingleScript
from Utils import ParseTime, GetDataWithBound


def ReadLabels(user_id):
    path = "/Users/zhangwenbo/Documents/研究生资料/代码/Geolife Trajectories 1.3 - 副本 - 副本" + "/Data" + "/" + user_id + "/labels.txt"
    print(path)
    label_list = []
    with open(path, 'r') as fp:
        for item in fp.readlines():
            item_list = re.split(r'[\t ]', item[:-1])
            label_list.append(item_list)
    return label_list


def GetSingleKinaData(user_id, label_list, search, kind):
    lat_str = []  # 纬度
    lng_str = []  # 经度
    time_str = []  # 时间
    date_time_str = []
    path = "/Users/zhangwenbo/Documents/研究生资料/代码/Geolife Trajectories 1.3 - 副本 - 副本" + "/Data" + "/" + user_id + "/Trajectory"
    plt_files = os.listdir(path)
    plt_files.sort()

    data = []  # 最终读取结果
    i = 0
    start_end_time = []
    choosed_path = []
    for item in plt_files:  # 每一个文件的绝对路径
        i += 1
        path_item = path + "/" + item
        # print(path)
        with open(path_item, 'r') as fp:
            lines = fp.readlines()
            start_line = lines[6].strip('\n').split(',')
            end_line = lines[-1].strip('\n').split(',')
            start = [start_line[5], start_line[6]]
            end = [end_line[5], end_line[6]]
            start_end_time.append((start, end))

            def Search(label_list, start, end):
                start[0] = start[0].replace('-', '/')
                end[0] = end[0].replace('-', '/')
                for item in label_list:
                    tmp_start = item[0:2]
                    tmp_end = item[2:4]
                    if start == tmp_start and end == tmp_end:
                        print(item[-1])
                        return item[-1]
                print("none")
                return "none"

            if search:
                if Search(label_list[1:], start, end) != kind:
                    continue
            choosed_path.append(path_item)
            for item in lines[6:]:
                item_list = item[:-1].split(',')
                lat_str.append(item_list[0])
                lng_str.append(item_list[1])
                time_str.append(item_list[6])

        lat_float = [float(x) for x in lat_str]
        lng_float = [float(x) for x in lng_str]
        time_int = [ParseTime(x) for x in time_str]
        data.append(list(zip(lat_float, lng_float, time_int)))
        lat_str, lng_str, lat_float, lng_float, time_str, time_int = [], [], [], [], [], []

    print("原始数据中共有轨迹条数: ", len(data))
    return data, choosed_path


def DeleteFiles(paths):
    path = "/Users/zhangwenbo/Documents/研究生资料/代码/Geolife Trajectories 1.3 - 副本 - 副本" + "/Data" + "/" + user_id + "/Trajectory"
    plt_files = os.listdir(path)
    plt_files.sort()
    for item in plt_files:  # 每一个文件的绝对路径
        path_item = path + "/" + item
        if path_item not in paths:
            os.remove(path_item)

# 纬度范围
minLat = 39.85
maxLat = 40.05
# 经度范围
minLng = 116.2
maxLng = 116.5
if __name__ == "__main__":
    user_id = "003"
    # out = ReadLabels(user_id=user_id)
    # data, paths = GetSingleKinaData(user_id, out, 1, "car")
    # # DeleteFiles(paths)

    data = GetDataWithBound(user_id, True, False, minLat, maxLat, minLng, maxLng)


    avg_lat = []
    avg_lng = []
    avg_t = []
    avg_traj_len = 0
    for traj in data:
        delta_lat = 0
        delta_lng = 0
        delta_t = 0
        for i in range(1, len(traj)):
            delta_lat += abs(traj[i][0] - traj[i-1][0])
            delta_lng += abs(traj[i][1] - traj[i-1][1])
            delta_t += abs(traj[i][2] - traj[i-1][2])
        delta_lat /= len(traj) - 1
        delta_lng /= len(traj) - 1
        delta_t /= len(traj) - 1
        avg_lat.append(delta_lat)
        avg_lng.append(delta_lng)
        avg_t.append(delta_t)
        avg_traj_len += len(traj)

    lng = sum(avg_lng) / 318
    lat = sum(avg_lat) / 318
    t = sum(avg_t) / 318
    avg_traj_len = avg_traj_len / 318

    a = 1
    # data = GetDataWithBound("128", True, False, min_lat=39.8, max_lat=40.2, min_lng=116.0, max_lng=116.7)
    # WriteSingleScript("../ShowTrajs/GeolifeDataShowScript/points_128.js", data)



