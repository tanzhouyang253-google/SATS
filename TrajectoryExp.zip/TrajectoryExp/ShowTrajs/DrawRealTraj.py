import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
# matplotlib画图中中文显示会有问题，需要这两行设置默认字体


def Draw(dummy, xmax=116.5728, xmin=116.1715, ymax=40.1075, ymin=39.7817):
    """
    绘制虚拟轨迹
    :param dummy: 单条虚拟轨迹(列表格式)
    :param xmax, xmin, ymaxm, ymin: 画布范围
    """
    plt.figure()
    plt.xlabel('Lng')
    plt.ylabel('Lat')
    plt.xlim(xmax=xmax, xmin=xmin)
    plt.ylim(ymax=ymax, ymin=ymin)
    color1 = '#FF0000'
    color2 = '#00FF00'
    area = np.pi * 4**2  # 点面积
    # 画折线图
    x = [i[1] for i in dummy]
    # print(x)
    y = [i[0] for i in dummy]
    # print(y)
    plt.plot(x, y)
    # 画起点、终点
    plt.scatter([x[0]], [y[0]], s=area, c=color1, alpha=1, label="起点")
    plt.scatter([x[-1]], [y[-1]], s=area, c=color2, alpha=1, label="终点")
    plt.legend()
    plt.show()


