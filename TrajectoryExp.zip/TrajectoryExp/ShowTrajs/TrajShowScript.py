import os

import numpy as np

from Utiliy.Utils import GetDataWithBound


def WriteScript(file_name, data):
    """
    生成一个可以可视化显示轨迹的脚本，修改html文件里引入的js文件目录即可在真实地图显示轨迹
    :param file_name: 要生成的.js文件名称
    :param data: [[traj1], [traj2], ....]，必须是真实经纬度表示的轨迹
    :return: None
    """
    num_trajs = len(data)
    with open(file_name, "w") as f:
        f.write('var map = new BMapGL.Map("allmap",{\n')
        f.write("	enableRotate: false,\n")
        f.write("	enableTilt: false\n")
        f.write("});\n")
        f.write("map.centerAndZoom(new BMapGL.Point(116.404, 39.915), 11);\n")
        f.write("var scaleCtrl = new BMapGL.ScaleControl();\n")
        f.write("map.addControl(scaleCtrl);\n")
        f.write("var zoomCtrl = new BMapGL.ZoomControl();\n")
        f.write("map.addControl(zoomCtrl);\n")
        f.write('var start_icon = new BMapGL.Icon("./img/start.png", new BMapGL.Size(30, 30));\n')
        f.write('var end_icon = new BMapGL.Icon("./img/end.png", new BMapGL.Size(30, 30));\n')
        f.write('map.enableScrollWheelZoom(true);\n')

        for i in range(num_trajs):  # 对每组轨迹
            print("{} / {}".format(i, num_trajs))
            f.write("var polyline{} = new BMapGL.Polyline([".format(i) + "\n")
            for item in data[i]:
                f.write("	new BMapGL.Point({}, {}),".format(item[1], item[0]))
            f.write("\n" + "], {strokeColor:\"red\", strokeWeight:5, strokeOpacity:0.9});" + "\n")
            f.write("map.addOverlay(polyline{});".format(i) + "\n")
            f.write("\n")

            # print(data[i])
            f.write("var start_point{} = new BMapGL.Point({}, {});".format(i, data[i][0][1], data[i][0][0]) + "\n")
            f.write("var start_marker = new BMapGL.Marker(start_point" + str(i) + ", {icon: start_icon});" + "\n")
            f.write("map.addOverlay(start_marker);" + "\n")

            f.write("var end_point{} = new BMapGL.Point({}, {});".format(i, data[i][-1][1], data[i][-1][0]) + "\n")
            f.write("var end_marker = new BMapGL.Marker(end_point" + str(i) + ", {icon: end_icon});" + "\n")
            f.write("map.addOverlay(end_marker);" + "\n")
            f.write("\n")


def WriteSingleScript(file_name, data):
    """
    对单个轨迹生成脚本
    :param file_name: 要生成的js文件名称
    :param data: [[traj1], [traj2], ....]，必须是真实经纬度表示的轨迹
    :return: None
    """
    data_without_time = []
    for traj in data:
        traj_without_time = [point[:2] for point in traj]
        data_without_time.append(traj_without_time)
    WriteScript(file_name, data_without_time)


def WriteAllGeolifeDataScript():
    """
    对于Geolife数据集中的所有轨迹生成可视化脚本
    :return: None
    """
    for i in range(182):
        if i < 10:
            user_id = "00" + str(i)
        elif i < 100:
            user_id = "0" + str(i)
        else:
            user_id = str(i)

        path = "../Geolife Trajectories 1.3 - 副本 - 副本" + "/Data" + "/" + user_id + "/Trajectory"  # Geolife在本机的路径
        # path = "..\\Geolife Trajectories 1.3 - 副本" + "\\Data" + "\\" + user_id + "\\Trajectory"
        plt_files = os.listdir(path)
        plt_files.sort()

        file_name = "./GeolifeDataShowScript/points_" + str(user_id) + ".js"
        print(file_name)

        lat_str = []  # 纬度
        lng_str = []  # 经度
        data = []  # 最终读取结果

        for item in plt_files:  # 每一个文件的绝对路径
            path_item = path + "/" + item
            # path_item = path + "\\" + item
            with open(path_item, 'r') as fp:
                for item in fp.readlines()[6:]:
                    item_list = item.split(',')
                    lat_str.append(item_list[0])
                    lng_str.append(item_list[1])
            lat_float = [float(x) for x in lat_str]
            lng_float = [float(x) for x in lng_str]
            data.append(list(zip(lat_float, lng_float)))
            lat_str = []
            lng_str = []

        data = data[:]
        WriteScript(file_name, data)


def DrawGrid(grid_num, min_lat, max_lat, min_lng, max_lng):
    delta_lng = max_lng - min_lng
    avg_delta_lng = delta_lng / grid_num
    all_x = np.arange(min_lng, max_lng, avg_delta_lng)
    delta_lat = max_lat - min_lat
    avg_delta_lat = delta_lat / grid_num
    all_y = np.arange(min_lat, max_lat, avg_delta_lat)


    vertical = [[(x, min_lat), (x, max_lat)] for x in all_x]
    horizontal = [[(min_lng, y), (max_lng, y)] for y in all_y]

    for item in vertical:
        print("var polyline = new BMapGL.Polyline([")
        print("    new BMapGL.Point({}, {}),".format(item[0][0], item[0][1]))
        print("    new BMapGL.Point({}, {}),".format(item[1][0], item[1][1]))
        print('], {strokeColor: "blue", strokeWeight: 2, strokeOpacity: 0.5});')
        print("map.addOverlay(polyline);")
    for item in horizontal:
        print("var polyline = new BMapGL.Polyline([")
        print("    new BMapGL.Point({}, {}),".format(item[0][0], item[0][1]))
        print("    new BMapGL.Point({}, {}),".format(item[1][0], item[1][1]))
        print('], {strokeColor: "blue", strokeWeight: 2, strokeOpacity: 0.5});')
        print("map.addOverlay(polyline);")


if __name__ == "__main__":
    # # WriteAllGeolifeDataScript()
    # data = GetDataWithBound("128", True, False, -90, 90, -180, 180)
    # WriteSingleScript("./GeolifeDataShowScript/points_128.js", data)
    DrawGrid(grid_num=256, min_lat=39.85, max_lat=40.05, min_lng=116.2, max_lng=116.5)
